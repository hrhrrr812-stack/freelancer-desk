import { createClient } from "@supabase/supabase-js";
export const supabaseUrl = "https://yiugcildbzlirakkpczs.supabase.co";
export const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlpdWdjaWxkYnpsaXJha2twY3pzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY1NzUwMDcsImV4cCI6MjA3MjE1MTAwN30.b3ol0-RFXpl3ht4hoBOmHJY9jPEu0D7c1QIsKaYUqUA"; // public anon key
export const supabase = createClient(supabaseUrl, supabaseKey);